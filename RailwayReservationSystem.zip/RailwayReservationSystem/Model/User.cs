﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace RailwayReservationSystem.Model
{
    public class User
    { 
        public int UserID { get; set; }
        public string fullname { get; set; } 
        public string mobilenumber { get; set; } 
        public string email { get; set; } 
        public string dateofbirth { get; set; } 
        public string address { get; set; } 
        public string pwd { get; set; }
        public DateTime MemberSince { get; set; }
    } 
}