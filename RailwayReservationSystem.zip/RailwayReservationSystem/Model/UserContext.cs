﻿using Microsoft.EntityFrameworkCore;

namespace RailwayReservationSystem.Model
{
    public class UserContext : DbContext
    {
        public UserContext(DbContextOptions Options) : base(Options)
        {

        }
        public DbSet<User> Users { get; set; }

    }

}
