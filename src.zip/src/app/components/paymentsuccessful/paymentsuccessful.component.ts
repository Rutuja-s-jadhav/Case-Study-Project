import { Component } from '@angular/core';

@Component({
  selector: 'app-paymentsuccessful',
  templateUrl: './paymentsuccessful.component.html',
  styleUrls: ['./paymentsuccessful.component.css']
})
export class PaymentsuccessfulComponent {

}
