import { NonNullAssert } from '@angular/compiler';
import { Component, OnInit} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  repeatPass: string ='none';

  displayMsg: string ='';
  isAccountCreated: boolean = false;
  constructor(private authService: AuthService) {}


  ngOnInit(): void {

  }

  // registerForm = new FormGroup({
    registerForm:FormGroup = new FormGroup({
    fullname: new FormControl("",[
      Validators.required,
      Validators.pattern("[a-zA-Z].*")
    ]),

    mobile: new FormControl("",[
      Validators.required,
      Validators.minLength(10),
      Validators.maxLength(10),
      Validators.pattern("[0-9]*")
    ]),

    email: new FormControl("", [
     Validators.required,
     Validators.email]),

    dateofbirth: new FormControl("", [
     Validators.required,
    ]),

    address: new FormControl("", [
      Validators.required,
    ]),

    pwd: new FormControl("", [
      Validators.required,
      Validators.minLength(4),
      Validators.maxLength(10),
    ]),
    rpwd: new FormControl("",[
      Validators.required,
      Validators.minLength(4),
      Validators.maxLength(10),
    ]),


  });

  registerSubmited(){
    if(this.PWD.value == this.RPWD.value){
     console.log(this.registerForm.valid);
     this.repeatPass = 'none';

     this.authService.
      registerUser([
        this.registerForm.value.fullname,
        this.registerForm.value.mobile,
        this.registerForm.value.email,
        this.registerForm.value.dateofbirth,
        this.registerForm.value.address,
        this.registerForm.value.pwd
      ])
      .subscribe((res => {
        if(res == 'Success'){
          this.displayMsg = 'Account created Succssfully!';
          this.isAccountCreated = true;
        }else if(res == 'AlreadyExist'){
          this.displayMsg ='Account Already exist. try another Email';
          this.isAccountCreated = false;

        }else{
          this.displayMsg ='Something went wrong';
          this.isAccountCreated = false;
        }
     }));

    }else{
     this.repeatPass="inline"
    }

   }


   get FullName(): FormControl {
     return this.registerForm.get("fullname") as FormControl;
   }

   get Mobile(): FormControl {
     return this.registerForm.get("mobile") as FormControl;
   }

   get Email(): FormControl {
     return this.registerForm.get("email") as FormControl;
   }


   get DateOfBirth(): FormControl {
     return this.registerForm.get("dateofbirth") as FormControl;

   }

   get Address(): FormControl {
     return this.registerForm.get("address") as FormControl;

   }

   get PWD(): FormControl {
     return this.registerForm.get("pwd") as FormControl;

   }

   get RPWD(): FormControl {
     return this.registerForm.get("rpwd") as FormControl;

   }
  }
