import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { BehaviorSubject } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }
  
  currentUser: BehaviorSubject<any> = new BehaviorSubject(null);
  jwtHelperService = new JwtHelperService();
   baseServerUrl = 'https://localhost:44363/api/';
   registerUser(user: Array<String>){
    return this.http.post(this.baseServerUrl + 'User/CreateUser',{
      fullname : user[0],
      mobilenumber : user[1],
      email : user[2],
      dateofbirth : user[3],
      address : user[4],
      pwd : user[5]
    },
    {
    responseType : 'text',
     }
   );
  }
  loginUser(loginInfo: Array<string>){
    return this.http.post(this.baseServerUrl + 'User/LoginUser', {
    Email: loginInfo[0],
    Pwd: loginInfo[1],
    },
    {
      responseType: 'text',
    }
    );
  }

  setToken(token: string){
    localStorage.setItem("access_token", token);
    this.loadCurrentUser();
   }

  loadCurrentUser(){
    const token = localStorage.getItem("access_token");
    const userInfo = token != null ? this.jwtHelperService.decodeToken(token) : null;
    const data = userInfo ? {
      id: userInfo.id,
      fullname: userInfo.fullname,
      mobilenumber: userInfo.mobilenumber,
      email: userInfo.email,
      dateofbirth: userInfo.dateofbirth,
      address: userInfo.address

    } : null;
    this.currentUser.next(data);
  }
  isLoggedin(): boolean{  
    return localStorage.getItem("access_token") ? true : false;
  }
  removeToken()
  { 
     localStorage.removeItem("access_token");
  }
}

 
